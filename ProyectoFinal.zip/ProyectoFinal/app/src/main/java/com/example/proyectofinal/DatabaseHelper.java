package com.example.proyectofinal;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "sinodalias.db";
    public static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Tabla Horarios
        db.execSQL(
                "CREATE TABLE horarios (" +
                        "id_horario INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "h1 INTEGER NOT NULL," +
                        "h2 INTEGER NOT NULL," +
                        "h3 INTEGER NOT NULL," +
                        "h4 INTEGER NOT NULL," +
                        "h5 INTEGER NOT NULL," +
                        "h6 INTEGER NOT NULL," +
                        "h7 INTEGER NOT NULL," +
                        "h8 INTEGER NOT NULL," +
                        "h9 INTEGER NOT NULL," +
                        "h10 INTEGER NOT NULL," +
                        "h11 INTEGER NOT NULL," +
                        "h12 INTEGER NOT NULL," +
                        "h13 INTEGER NOT NULL" +
                        ");"
        );

        // Tabla Maestros (Cada maestro usa un horario)
        db.execSQL(
                "CREATE TABLE maestros (" +
                        "id_maestro INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "nombre TEXT NOT NULL," +
                        "id_horario INTEGER NOT NULL," +
                        "FOREIGN KEY(id_horario) REFERENCES horarios(id_horario)" +
                        ");"
        );

        // Tabla Sinodalias
        db.execSQL(
                "CREATE TABLE sinodalias (" +
                        "id_sinodalia INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "fecha TEXT NOT NULL," +
                        "hora INTEGER NOT NULL," +
                        "id_maestro1 INTEGER NOT NULL," +
                        "id_maestro2 INTEGER NOT NULL," +
                        "id_maestro3 INTEGER NOT NULL," +
                        "id_maestro4 INTEGER NOT NULL," +
                        "FOREIGN KEY(id_maestro1) REFERENCES maestros(id_maestro)," +
                        "FOREIGN KEY(id_maestro2) REFERENCES maestros(id_maestro)," +
                        "FOREIGN KEY(id_maestro3) REFERENCES maestros(id_maestro)," +
                        "FOREIGN KEY(id_maestro4) REFERENCES maestros(id_maestro)" +
                        ");"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS sinodalias");
        db.execSQL("DROP TABLE IF EXISTS maestros");
        db.execSQL("DROP TABLE IF EXISTS horarios");
        onCreate(db);
    }
}

