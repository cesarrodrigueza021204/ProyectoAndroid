package com.example.proyectofinal;

public class Sinodalia {

    private int id;
    private String fecha;
    private int hora;
    private String maestro1;
    private String maestro2;
    private String maestro3;
    private String maestro4;

    public Sinodalia(){

    }
    public Sinodalia(int id, String fecha, int hora,
                     String m1, String m2, String m3, String m4) {
        this.id = id;
        this.fecha = fecha;
        this.hora = hora;
        this.maestro1 = m1;
        this.maestro2 = m2;
        this.maestro3 = m3;
        this.maestro4 = m4;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getHora() {
        return hora;
    }

    public void setHora(int hora) {
        this.hora = hora;
    }

    public String getMaestro1() {
        return maestro1;
    }

    public void setMaestro1(String maestro1) {
        this.maestro1 = maestro1;
    }

    public String getMaestro2() {
        return maestro2;
    }

    public void setMaestro2(String maestro2) {
        this.maestro2 = maestro2;
    }

    public String getMaestro3() {
        return maestro3;
    }

    public void setMaestro3(String maestro3) {
        this.maestro3 = maestro3;
    }

    public String getMaestro4() {
        return maestro4;
    }

    public void setMaestro4(String maestro4) {
        this.maestro4 = maestro4;
    }
}

