package com.example.proyectofinal;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class Adaptador extends BaseAdapter {
    ArrayList<Sinodalia> lista;
    SinodaliaDao dao;
    Sinodalia s;
    Activity a;

public Adaptador(Activity a, ArrayList<Sinodalia> lista, SinodaliaDao dao){
    this.lista = lista;
    this.a = a;
    this.dao = dao;
}
    @Override
    public int getCount() {
        return lista.size();
    }

    @Override
    public Sinodalia getItem(int i) {
        s = lista.get(i);
        return null;
    }

    @Override
    public long getItemId(int i) {
        s=lista.get(i);
        return s.getId();
    }

    @Override
    public View getView(int posicion, View view, ViewGroup viewGroup) {
        View v = view;
        if(v!=null){
            LayoutInflater li= (LayoutInflater) a.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v=li.inflate(R.layout.item,null);
        }
        s = lista.get(posicion);
        TextView fecha = (TextView)v.findViewById(R.id.t_fecha);
        TextView hora = (TextView)v.findViewById(R.id.t_hora);
        TextView maestro1 = (TextView)v.findViewById(R.id.t_Maestro1);
        TextView maestro2 = (TextView)v.findViewById(R.id.t_Maestro2);
        TextView maestro3 = (TextView)v.findViewById(R.id.t_Maestro3);
        TextView maestro4 = (TextView)v.findViewById(R.id.t_Maestro4);
        Button editar =(Button)v.findViewById(R.id.editar);
        Button eliminar =(Button)v.findViewById(R.id.elimiar);

        fecha.setText(s.getFecha());
        hora.setText(s.getHora());
        maestro1.setText(s.getMaestro1());
        maestro2.setText(s.getMaestro2());
        maestro3.setText(s.getMaestro3());
        maestro4.setText(s.getMaestro4());
        editar.setTag(posicion);
        eliminar.setTag(posicion);
        editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Dialogo de editar dialogo.xml
            }
        });
        eliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //dialogo para confirmar si o no
            }
        });


        return v;
    }
}
