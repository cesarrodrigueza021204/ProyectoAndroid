package com.example.proyectofinal;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "sinodalias.db";
    public static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Tabla Horarios
        db.execSQL(
                "CREATE TABLE horarios (\n" +
                        "    id_horario INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                        "    h7  INTEGER NOT NULL,\n" +
                        "    h8  INTEGER NOT NULL,\n" +
                        "    h9  INTEGER NOT NULL,\n" +
                        "    h10 INTEGER NOT NULL,\n" +
                        "    h11 INTEGER NOT NULL,\n" +
                        "    h12 INTEGER NOT NULL,\n" +
                        "    h13 INTEGER NOT NULL,\n" +
                        "    h14 INTEGER NOT NULL,\n" +
                        "    h15 INTEGER NOT NULL,\n" +
                        "    h16 INTEGER NOT NULL,\n" +
                        "    h17 INTEGER NOT NULL,\n" +
                        "    h18 INTEGER NOT NULL,\n" +
                        "    h19 INTEGER NOT NULL\n" +
                        ");"
        );

        // Tabla Maestros (Cada maestro usa un horario)
        db.execSQL(
                "CREATE TABLE maestros (" +
                        "id_maestro INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "nombre TEXT NOT NULL," +
                        "id_horario INTEGER NOT NULL," +
                        "FOREIGN KEY(id_horario) REFERENCES horarios(id_horario)" +
                        ");"
        );

        // Tabla Sinodalias
        db.execSQL(
                "CREATE TABLE sinodalias (\n" +
                        "    id_sinodalia INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                        "    fecha DATE NOT NULL,\n" +
                        "    hora INTEGER NOT NULL,\n" +
                        "    id_maestro1 INTEGER NOT NULL,\n" +
                        "    id_maestro2 INTEGER NOT NULL,\n" +
                        "    id_maestro3 INTEGER NOT NULL,\n" +
                        "    id_maestro4 INTEGER NOT NULL,\n" +
                        "    FOREIGN KEY(id_maestro1) REFERENCES maestros(id_maestro),\n" +
                        "    FOREIGN KEY(id_maestro2) REFERENCES maestros(id_maestro),\n" +
                        "    FOREIGN KEY(id_maestro3) REFERENCES maestros(id_maestro),\n" +
                        "    FOREIGN KEY(id_maestro4) REFERENCES maestros(id_maestro)\n" +
                        ");"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS sinodalias");
        db.execSQL("DROP TABLE IF EXISTS maestros");
        db.execSQL("DROP TABLE IF EXISTS horarios");
        onCreate(db);
    }



}

