package com.example.proyectofinal;

import android.content.Context;
import android.database.sqlite.SQLiteAbortException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class SinodaliaDao {
    SQLiteDatabase cx;
    ArrayList<Sinodalia> lista;
    Sinodalia s;
    Context ct;
    String nombreBD = "sinodalias";
    String tabla = "CREATE TABLE sinodalias (\n" +
            "    id_sinodalia INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
            "    fecha DATE NOT NULL,\n" +
            "    hora INTEGER NOT NULL,\n" +
            "    id_maestro1 INTEGER NOT NULL,\n" +
            "    id_maestro2 INTEGER NOT NULL,\n" +
            "    id_maestro3 INTEGER NOT NULL,\n" +
            "    id_maestro4 INTEGER NOT NULL,\n" +
            "    FOREIGN KEY(id_maestro1) REFERENCES maestros(id_maestro),\n" +
            "    FOREIGN KEY(id_maestro2) REFERENCES maestros(id_maestro),\n" +
            "    FOREIGN KEY(id_maestro3) REFERENCES maestros(id_maestro),\n" +
            "    FOREIGN KEY(id_maestro4) REFERENCES maestros(id_maestro)\n" +
            ")";
    public SinodaliaDao (Context c){
        this.ct = c;
        cx = c.openOrCreateDatabase(nombreBD,Context.MODE_WORLD_WRITEABLE,null);
        cx.execSQL(tabla);
    }
    public boolean insertar(Sinodalia s){


        return true;
    }

    public boolean eliminar(int id){

        return true;
    }

    public boolean editar(Sinodalia s){

        return true;
    }

    public ArrayList <Sinodalia> verTodos(){
        return  lista;
    }

    public Sinodalia verUno (int id){
        return s;
    }
}
