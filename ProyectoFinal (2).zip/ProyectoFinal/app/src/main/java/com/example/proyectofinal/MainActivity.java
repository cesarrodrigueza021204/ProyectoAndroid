package com.example.proyectofinal;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    SinodaliaDao dao;
    Adaptador adapter;
    ArrayList<Sinodalia> lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        dao = new SinodaliaDao(this);
        lista = dao.verTodos();
        adapter = new Adaptador(this,lista,dao);
        ListView list=(ListView)findViewById(R.id.lista);
        Button agregar = (Button)findViewById(R.id.buttonAgregar);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Dialogo para ver vista previa de registro vista.xml
            }
        });
        agregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Dialogo de agregar dialogo.xml
                Dialog dialogo = new Dialog(MainActivity.this);
                dialogo.setTitle("Nevo registro");
                dialogo.setCancelable(true);
                dialogo.setContentView(R.layout.agregar_sinodalia);
                dialogo.show();
                EditText  = (EditText)dialogo.findViewById(R.id.)
            }
        });


    }


}